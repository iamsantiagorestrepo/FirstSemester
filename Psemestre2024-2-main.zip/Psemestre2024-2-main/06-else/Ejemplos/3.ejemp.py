#Uso de if-else:

temperatura = 25
if temperatura > 30:
    print("Hace calor")
else:
    print("La temperatura es agradable")