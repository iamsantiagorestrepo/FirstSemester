edad = 18
if edad >= 18:
    print("Eres mayor de edad")

    #Uso básico de if:

