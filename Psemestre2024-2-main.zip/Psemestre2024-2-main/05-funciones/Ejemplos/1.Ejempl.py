"""
def nombre_de_la_funcion(parametro1, parametro2, ...):
    # Cuerpo de la función
    # Código que realiza la tarea
    return resultado  # Opcional

Elementos clave:

def: Palabra clave para definir una función.
nombre_de_la_funcion: Nombre que le das a la función.
parametros: Valores que la función puede recibir (opcionales).
return: Palabra clave para devolver un resultado (opcional).



"""