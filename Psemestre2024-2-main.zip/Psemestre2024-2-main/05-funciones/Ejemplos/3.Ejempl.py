#Función con parámetros:

def sumar(a, b):
    return a + b

# Llamada a la función
resultado = sumar(3, 5)
print(resultado)  # Imprime: 8