#Función simple sin parámetros:

def saludar():
    print("¡Hola, mundo!")

# Llamada a la función
saludar()  # Imprime: ¡Hola, mundo!
