numero = int(input("Ingrese un número: "))

if 10 <= numero <= 20:
    print("El número está entre 10 y 20.")
else:
    print("El número está fuera del rango.")