calificacion = float(input("Ingrese su calificación: "))

if calificacion >= 90:
    print("Excelente")
elif calificacion >= 80:
    print("Muy bueno")
elif calificacion >= 70:
    print("Bueno")
elif calificacion >= 60:
    print("Regular")
else:
    print("Suspenso")