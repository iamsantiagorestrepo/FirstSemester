edad_anos = int(input("Ingrese su edad en años: "))

edad_meses = edad_anos * 12
edad_dias = edad_anos * 365
edad_horas = edad_dias * 24

print("Tu edad equivale a:")
print(edad_meses, "meses")
print(edad_dias, "días")
print(edad_horas, "horas")