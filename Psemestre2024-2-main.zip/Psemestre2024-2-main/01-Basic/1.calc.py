num1 = 9
num2 = 3

suma = num1 + num2
restando = num1 - num2
multiplicacion = num1 * num2
division = num1 / num2

print("Suma:", suma)
print("Resta:", restando)
print("Multiplicación:", multiplicacion)
print(f"División:, {division}")

"""
iou qioefwiohpqefwoiphioqerwioqewirqefwiefwqpfwiofqewiqefwihoqfewioihpoqefw
"""
#gyfgjkhasjDSKADSKJAHDSJ









