# comentarIO


# identacion
x = 10
y = 20
if x >y:
    print("x es mayor que y")
else:
    print("x es menor que y")
# operadores
# hola soy un comentario
# accesos rapidos https://shortcutworld.com/PhpStorm/win/JetBrains-PhpStorm_Shortcuts

#📗 Operadores de asignación
x=12       # Uso correcto del operador =
print(x)  # 2
#3=5      # Daría error, 3 no es una variable

#📗 Operadores Aritméticos
#📗 Operadores Relacionales
#📗 Operadores Lógicos

nombre = "ana"
apellido = "lopez"
print(f"")