metros = float(input("Ingrese la cantidad en metros: "))

centimetros = metros * 100
kilometros = metros / 1000

print(metros, "metros equivalen a:")
print(centimetros, "centímetros")
print(kilometros, "kilómetros")