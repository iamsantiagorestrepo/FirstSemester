calificacion = float(input("Ingrese su calificación: "))
if calificacion >= 70:
    print("Aprobaste.")
else:
    print("Reprobaste.")