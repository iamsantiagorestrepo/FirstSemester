print(True and False)  # False
print(True or False)   # True
print(not True)        # False