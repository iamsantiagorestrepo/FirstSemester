numero = int(input("Ingrese un número: "))
if 1 <= numero <= 100:
    print("El número está entre 1 y 100.")
else:
    print("El número está fuera del rango.")