#Verifica si 'a' es menor que 'b' y 'c' es mayor que 'd', pero 'b' no es igual a 5:
"""a, b, c, d = 4, 5, 9, 7
resultado = (a < b) and (c > d) and not (b == 5)
print(resultado)  # False
"""
