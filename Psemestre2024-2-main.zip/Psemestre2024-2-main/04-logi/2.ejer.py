#Comprueba si 'a' es par o si 'c' es impar:
a, b, c, d = 3, 9, 3, 7
resultado = not(a % 2 == 0) or (c % 2 != 0)
print(resultado)  # True

