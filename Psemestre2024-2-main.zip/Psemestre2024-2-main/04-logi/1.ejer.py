#Verifica si 'a' es menor que 'b' y 'c' es mayor que 'd':
a, b, c, d = 4, 5, 9, 7
resultado = (a < b) and (c > d)
print(resultado)  #