resultado1 = (((2 + (3 * 4)) > 10) and ((5 ** 2) == 25)) or (not False)
print(resultado1)

#resultado1 = 2 + 3 * 4 > 10 and 5 ** 2 == 25 or not


#Ejercico2
resultado2 = ((10 + (5 * 2)) > 15) and ((30 / 3) == 10) or (not ((2 ** 3) != 8))
print(resultado2)