#Evalúa si 'b' está entre 'a' y 'c', y si 'd' no es igual a 'b':
a, b, c, d = 4, 5, 9, 7
resultado = (a < b < c) and (d != b)
print(resultado)  # True
