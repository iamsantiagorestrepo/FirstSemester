#Verifica si la suma de 'a' y 'b' es mayor que 'c', o si 'd' es menor que 'a':



a, b, c, d = 4, 5, 9, 7
resultado = ((a + b) > c) or (d < a)
print(resultado)  # False