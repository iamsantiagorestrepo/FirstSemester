#Comprueba si 'a' es menor que 'b', 'c' es mayor que 'd', y 'b' es menor que 'd':
a, b, c, d = 4, 5, 9, 7
resultado = (a < b) and (c > d) and (b < d)
print( resultado)  # True